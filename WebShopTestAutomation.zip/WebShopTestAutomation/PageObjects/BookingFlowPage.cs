﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using WebShopTestAutomation.Drivers;
using OpenQA.Selenium.Support.UI;

namespace WebShopTestAutomation.PageObjects
{
   public class BookingFlowPage
    {
        private WebDriverWait wait;
       
        WebDriver driver;
        bool desktop = true;
        public BookingFlowPage(WebDriver webDriver)
        {

            this.driver = webDriver;
          
            wait = new WebDriverWait(driver.Current(out desktop), TimeSpan.FromSeconds(60));

        }

        public IWebElement GetHouseRental()
        {
            IWebElement HouseRental = wait.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.ElementExists(By.XPath("//li[contains(@class, 'booking-overview__total')]//span")));
            return HouseRental;
        }
       
        public IWebElement GetPropertyId()
        {
            IWebElement PropertyId = wait.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.ElementExists(By.XPath("//div[contains(@class,'house-header')]/h2")));
            return PropertyId;
        }

        public IWebElement Title()
        {
            IWebElement title = wait.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.ElementExists(By.Id("title")));
            return title;
        }

         public IWebElement FirstName()
        {
            IWebElement firstName = wait.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.ElementExists(By.Id("firstName")));
            return firstName;
        }

        public IWebElement LastName()
        {
            IWebElement lastName = wait.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.ElementExists(By.Id("lastName")));
            return lastName;
        }

        public IWebElement Email()
        {
            IWebElement email = wait.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.ElementExists(By.Id("email")));
            return email;
        }
        public IWebElement VerifyEmail()
        {
            IWebElement verifyEmail = wait.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.ElementExists(By.Id("emailVerify")));
            return verifyEmail;
        }
        public IWebElement Phone()
        {
            IWebElement phone = wait.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.ElementExists(By.Id("phone")));
            return phone;
        }
        public IWebElement AdditionalPhone()
        {
            IWebElement additionalPhone = wait.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.ElementExists(By.Id("additionalPhone")));
            return additionalPhone;
        }
        public IWebElement Address()
        {
            IWebElement address = wait.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.ElementExists(By.Id("street")));
            return address;
        }
        public IWebElement Floor()
        {
            IWebElement floor = wait.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.ElementExists(By.Id("streetNumber")));
            return floor;
        }
        public IWebElement HouseNumber()
        {
            IWebElement houseNumber = wait.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.ElementExists(By.Id("floor")));
            return houseNumber;
        }
        public IWebElement AdditionalAddress()
        {
            IWebElement additionalAddress = wait.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.ElementExists(By.Id("additionalAddress")));
            return additionalAddress;
        }
        public IWebElement PostalCode()
        {
            IWebElement postalCode = wait.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.ElementExists(By.Id("zipCode")));
            return postalCode;
        }
        public IWebElement City()
        {
            IWebElement city = wait.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.ElementExists(By.Id("city")));
            return city;
        }

        public IWebElement Country()
        {
            IWebElement country = wait.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.ElementExists(By.Id("customerCountry")));
            return country;
        }

        public IList<IWebElement> CountryDropDown()
        {
            IWebElement countryDropDown = wait.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.ElementExists(By.XPath("//input[@id='customerCountry'][@aria-expanded='true']")));
            IList<IWebElement> lstcountryDropDown = driver.Current(out desktop).FindElements(By.XPath("//input[@id='customerCountry'][@aria-expanded='true']"));
            return lstcountryDropDown;
        }


        public IWebElement PaymentOption()
        {
            IWebElement paymentOption = wait.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.ElementExists(By.XPath("//div[contains(@class, 'pay-option')]//div[(@class ='Select-input')]")));
            return paymentOption;
        }

        public IWebElement AcceptTerms()
        {
            IWebElement acceptTerms = wait.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.ElementExists(By.Id("acceptTerms")));
            return acceptTerms;
        }

        public IWebElement BookingRequestButton()
        {
            IWebElement bookingRequestButton = wait.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.ElementExists(By.XPath("//button[contains(@class, 'booking-overview__confirm')]")));
            return bookingRequestButton;
        }

        

    }
}
