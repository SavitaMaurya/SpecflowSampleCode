﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using WebShopTestAutomation.Drivers;
using OpenQA.Selenium.Support.UI;

namespace WebShopTestAutomation.PageObjects
{
    public class MapPage
    {

        private WebDriverWait wait;
       
        WebDriver driver;
        bool desktop = true;
        public MapPage(WebDriver webDriver)
        {

            this.driver = webDriver;

            wait = new WebDriverWait(driver.Current(out desktop), TimeSpan.FromSeconds(60));
        }
        public IWebElement GoToMap()
        {
            IWebElement map = wait.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.ElementExists(By.XPath("//div[contains(@class, 'search-map__map')]")));
            return map;
        }
        public IWebElement GetCollapseMap()
        {
            IWebElement CollapseMap = wait.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.ElementExists(By.XPath("//button[contains(@class, 'search-map__expand-button')]")));
            return CollapseMap;
        }
        public IWebElement ZoomInButton()
        {
            IWebElement zoomInButton = wait.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.ElementExists(By.XPath("//div[contains(@class, 'solar-custom-map-buttons--plus')]")));
            return zoomInButton;
        }

        public IWebElement ZoomOutButton()
        {
            IWebElement zoomOutButton = wait.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.ElementExists(By.XPath("//div[contains(@class, 'solar-custom-map-buttons--minus')]")));
            return zoomOutButton;
        }

        public IWebElement UpdateListCheckBox()
        {
            IWebElement updateListCheckBox = wait.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.ElementExists(By.XPath("//div[contains(@class, 'checkbox--active')]")));
            return updateListCheckBox;
        }

        public IWebElement HouseOnSearchResultPage()
        {
            IWebElement houseSearchResult = wait.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.ElementExists(By.XPath("//div[contains(@class, 'search-results__item')]//div[contains(@class, 'house-card__body')]")));
            return houseSearchResult;
        }

        public IWebElement GetHouseMarker()
        {
          IWebElement houseMarker = wait.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.ElementExists(By.XPath("//div[contains(@class, 'search-map__hover-marker--house')]")));
            return houseMarker;
        }

        public IWebElement GetMapHouseCard()
        {
            IWebElement mapHouseCard = wait.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.ElementExists(By.XPath("//div[contains(@class, 'search-map__house-card')]")));
            return mapHouseCard;
        }
        public IWebElement GetCloseHouseMarkerSymbol()
        {
            IWebElement houseCloseSymbol = wait.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.ElementExists(By.XPath("//div[contains(@class, 'house-card--closable')]//div[contains(@class, 'house-card__close-button')]")));
            return houseCloseSymbol;
        }
    }
}
