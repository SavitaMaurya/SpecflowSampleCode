﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using WebShopTestAutomation.Drivers;
using OpenQA.Selenium.Interactions;
using OpenQA.Selenium.Support.UI;

namespace WebShopTestAutomation.PageObjects
{
    public class ThemePage
    {
        private WebDriverWait wait;

        WebDriver driver;
        bool desktop = true;
        public ThemePage(WebDriver webDriver)
        {

            this.driver = webDriver;

            wait = new WebDriverWait(driver.Current(out desktop), TimeSpan.FromSeconds(60));

        }

        public IWebElement GetDogFriendlyImageButton()
        {
            IWebElement dogFriendlyButton = wait.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.ElementExists(By.XPath("//div[contains(@class, 'theme-entry-page')]//a[contains(@class, 'theme-entry-page__item-link')]//img[contains(@src, 'dog')]")));
            return dogFriendlyButton;

        }
       
        public IWebElement GetDestinationThemes()
        {
            IWebElement destinationTheme = wait.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.ElementExists(By.XPath("//div[contains(@class, 'region-content')]//li[contains(@class, 'theme-entry-page__item')]")));
            return destinationTheme;
        }
        public IWebElement GetDiscoverDogFriendlyButton()
        {
            IWebElement petIcon = wait.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.ElementExists(By.XPath("//button[contains(@class, 'button--secondary')]")));
            return petIcon;
        }
        public IWebElement GetPetIcon()
        {
            //IWebElement petIcon = wait.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.ElementExists(By.XPath("//div[contains(@class, 'rental-concepts')]//li[contains(@class, 'rental-concepts__concept')]//img[contains(@src,'iconPetGreen')]")));
            IWebElement petIcon = wait.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.ElementExists(By.XPath("//section[contains(@class, 'rental-icons')]//div[contains(@class, 'card-feature--pets')]")));
            return petIcon;
        }
    }
}
