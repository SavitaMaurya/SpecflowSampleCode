﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using WebShopTestAutomation.Drivers;
using OpenQA.Selenium.Support.UI;
using System.Collections.ObjectModel;

namespace WebShopTestAutomation.PageObjects
{
    public class HousePresentation
    {

        private WebDriverWait wait;
        WebDriver driver;
        bool desktop = true;
        public HousePresentation(WebDriver webDriver)
        {

            this.driver = webDriver;

            wait = new WebDriverWait(driver.Current(out desktop), TimeSpan.FromSeconds(180)); // as giving timeout in docker( Jan 2020)

        }


        public IWebElement GetBookButton()
        {
            //IWebElement BookButton = wait.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.ElementExists(By.XPath("//a[contains(@class, 'booking-button')]")));
            //chnages on 3rd Dec 2019
            IWebElement BookButton = wait.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.ElementExists(By.XPath("//a[contains(@class, 'booking-button--valid')]")));
            return BookButton;
        }
        public IWebElement GetCatalogueNumber()
        {
            IWebElement CatalogueNumber = null;
            try
            {
                try
                {
                    //Console.WriteLine("Taking HousePresentationPage snapshot at Entry at  : " + DateTime.UtcNow);
                    ////take screenshot
                    //((ITakesScreenshot)driver.Current(out desktop)).GetScreenshot().SaveAsFile("HousePresentationEntry.png", ScreenshotImageFormat.Png);

                    Console.WriteLine("HousePresentation.cs GetCatalogueNumber Entry at : "+  DateTime.UtcNow);
                  
                    CatalogueNumber = wait.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.ElementExists(By.XPath("//div[@class = 'rental-overview__catalogue-number']")));
                    Console.WriteLine("HousePresentation.cs GetCatalogueNumber Exit at : " + DateTime.UtcNow);
                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex);

                    Console.WriteLine(" Failed to fetch will try to get again after page refresh at : " + DateTime.UtcNow);
                    //driver.Current(out desktop).Navigate().Refresh();
                    driver.Current(out desktop).Manage().Timeouts().PageLoad = TimeSpan.FromSeconds(60);
                    //Console.WriteLine(" Page refreshed successfully");
                    CatalogueNumber = wait.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.ElementExists(By.XPath("//div[@class = 'rental-overview__catalogue-number']")));
                    Console.WriteLine(" Retry success at : " + DateTime.UtcNow);

                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex);

                Console.WriteLine("Taking HousePresentationPage snapshot at : " + DateTime.UtcNow);
                //take screenshot
                ((ITakesScreenshot)driver.Current(out desktop)).GetScreenshot().SaveAsFile("HousePresentationError.png", ScreenshotImageFormat.Png);
                Console.WriteLine("Snapshot taken successfully");
                //throw ex; //disabling as its giving false error inside docker
            }
            return CatalogueNumber;
        }


        public IWebElement GetHouseRental()
        {
            IWebElement HouseRental = wait.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.ElementExists(By.XPath("//span[contains(@class, 'pricebox__wrap-price--price')]/span")));
            return HouseRental;
        }

        public IWebElement GetHPRightImageArrow()
        {
            IWebElement HPRightImageArrow = wait.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.ElementToBeClickable(By.XPath("//button[contains(@class, 'rental-assets__button-nav--next')]")));
            return HPRightImageArrow;
        }

        public IWebElement HPGalleryImage()
        {
            IWebElement HPGalleryImage = wait.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.ElementExists(By.XPath("//img[contains(@class, 'rental-assets__cell-img')]")));
            return HPGalleryImage;
        }

        public IWebElement IsRightImageArrowEnd()
        {
            IWebElement RightImageArrowEnd = wait.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.ElementExists(By.XPath("//button[contains(@class, 'rental-assets__button-nav--next')]")));
            return RightImageArrowEnd;
        }
        public IWebElement HpImagesDiv()
        {
            IWebElement HpImagesDiv = wait.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.ElementExists(By.XPath("//div[contains(@class, 'rental-assets__cell')]")));
            return HpImagesDiv;
        }
        //public IList<IWebElement> GetHPLeftImageArrow()
        //{
        //    wait.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.ElementToBeClickable(By.XPath("//button[contains(@class, 'flickity-button')][@aria-label ='Previous']/*[name()='svg']")));
        //    IList<IWebElement> HPLeftImageArrow = driver.Current(out desktop).FindElements(By.XPath("//button[contains(@class, 'flickity-button')][@aria-label ='Previous']/*[name()='svg']"));
        //    return HPLeftImageArrow;
        //}

        public IWebElement GetHPLeftImageArrow()
        {
            IWebElement HPLeftImageArrow = wait.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.ElementToBeClickable(By.XPath("//button[contains(@class, 'rental-assets__button-nav--previous')]")));
            return HPLeftImageArrow;
        }
        public IWebElement IsLeftImageArrowEnd()
        {
            IWebElement LeftImageArrowEnd = wait.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.ElementExists(By.XPath("//button[contains(@class, 'rental-assets__button-nav--previous')]")));
            return LeftImageArrowEnd;
        }
        public List<IWebElement> GetFloorPlan()
        {
            List<IWebElement> HouseRental = driver.Current(out desktop).FindElements(By.XPath("//span[contains(@class, 'rental-assets-button--floorplan')]")).ToList();
            return HouseRental;
        }

        public IWebElement GetArrivalCalender()
        {
            //IWebElement ArrivalCalender = wait.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.ElementExists(By.XPath("//div[contains(@class, 'DateRangePickerInput')]//input[@id ='startDate']")));
            IWebElement ArrivalCalender = wait.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.ElementExists(By.XPath("//div[contains(@class, 'DateRangePickerInput')]//div[contains(@class, 'DateInput')]")));
            return ArrivalCalender;
        }

        public IWebElement GetCalenderRightArrow()
        {
            IWebElement ArrivalCalender = wait.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.ElementExists(By.XPath("//div[contains(@class, 'DayPickerNavigation')]//button[contains(@class, 'DayPickerNavigation__next')]")));
            return ArrivalCalender;
        }


        public IList<IWebElement> SelectArrivalDate()
        {
            wait.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.ElementExists(By.XPath("//div[contains(@class, 'CalendarMonth--horizontal')][@data-visible='true']//td[contains(@class, 'CalendarDay--valid')]/button[contains(@class, 'CalendarDay__button')]")));

            IList<IWebElement> lstArrivalDate = driver.Current(out desktop).FindElements(By.XPath("//div[contains(@class, 'CalendarMonth--horizontal')][@data-visible='true']//td[contains(@class, 'CalendarDay--valid')]/button[contains(@class, 'CalendarDay__button')]"));

            return lstArrivalDate;
        }

        public IWebElement GetPersonButtonOfCalender()
        {
            IWebElement PersonButton = wait.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.ElementExists(By.XPath("//div[contains(@class, 'guestpicker__button')]//button[contains(@class, 'button')]")));
            return PersonButton;
        }
        public IWebElement GetAboutPropertySubMenu()
        {
            IWebElement AboutProperty = wait.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.ElementExists(By.XPath("//div[contains(@class, 'rental-submenu__wrapper')]//a[contains(@href, '#about-house')]")));
            return AboutProperty;
        }

        public IWebElement CheckOnAboutProperty()
        {
            IWebElement OnAboutProperty = wait.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.ElementExists(By.XPath("//div[contains(@class, 'rental-facilities')]")));
            return OnAboutProperty;
        }
        public IWebElement CheckFloorPlanDisplayed()
        {
            IWebElement OnAboutProperty = wait.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.ElementExists(By.XPath("//div[contains(@class, 'rental-assets__cell--floorplan')]")));
            return OnAboutProperty;
        }

        public IWebElement GetCloseFloorPlanIcon()
        {
            IWebElement OnAboutProperty = wait.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.ElementExists(By.XPath("//button[contains(@class, 'rental-lightbox__button--close')]")));
            return OnAboutProperty;
        }

        public IList<IWebElement> GetNearByMenu()
        {
            wait.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.ElementToBeClickable(By.XPath("//div[contains(@class, 'house-map-interest__list')]//div[contains(@class, 'house-map-interest__interest-point')]")));
            IList<IWebElement> NearByMenu = driver.Current(out desktop).FindElements(By.XPath("//div[contains(@class, 'house-map-interest__list')]//div[contains(@class, 'house-map-interest__interest-point')]/input"));
            return NearByMenu;
        }

        public IWebElement CheckAirportShownOnMap()
        {
            // IWebElement OnAirport = wait.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.ElementExists(By.XPath("//div[contains(@class, 'rental-map')]//div[contains(@class, 'house-map-interest__marker')]//img[contains(@src, 'Airport')]")));
            IWebElement OnAirport = wait.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.ElementExists(By.XPath("//div[@id= 'house-map']//div[contains(@class, 'house-map-interest__marker')]//img[contains(@src, 'Airport')]")));

            return OnAirport;
        }

        public IWebElement CheckSimilarHousesOnPage()
        {
            IWebElement OnAboutProperty = wait.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.ElementExists(By.XPath("//div[contains(@class, 'similar-houses')]//h3")));
            return OnAboutProperty;
        }

        public IWebElement CheckAllSimilarHouses()
        {
            IWebElement allSimilarHouses = wait.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.ElementExists(By.XPath("//a[contains(@class, 'similar-houses__button')]")));
            return allSimilarHouses;
        }
        public IWebElement GetSocialSharingIcon()
        {
            IWebElement SocialSharing = wait.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.ElementExists(By.XPath("//span[contains(@class, 'rental-assets-button--share')]/i")));
            return SocialSharing;
        }

        public IWebElement GetBackToSearchButton()
        {
            IWebElement BackToSearchButton = wait.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.ElementExists(By.XPath("//a[contains(@class,'rental-back-to-search__button')]")));
            return BackToSearchButton;
        }


        public IWebElement GetHPMapInput()
        {
            IWebElement HPMapInput = wait.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.ElementExists(By.XPath("//input[@id ='rental-map__origin']")));
            return HPMapInput;
        }

        public IWebElement GetSocialSharingOverlay()
        {
            IWebElement SocialSharingOverlay = wait.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.ElementExists(By.XPath("//div[contains(@class, 'rental-share group')]")));
            return SocialSharingOverlay;
        }

        public IWebElement GetCloseSocialSharingOverlay()
        {
            IWebElement CloseSocialSharingOverlay = wait.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.ElementExists(By.XPath("//div[contains(@class, 'rental-share group')]/a[contains(@class, 'rental-share__close')]")));
            return CloseSocialSharingOverlay;
        }

        public IWebElement NewsLetterSection()
        {
            IWebElement newsletterSection = wait.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.ElementExists(By.XPath("//section[contains(@class, 'newsletter-section')]")));
            return newsletterSection;
        }
        public void WaitTillNewWindowIsOpen()
        {
            Console.WriteLine("In WaitTillNewWindowIsOpen method HousePresentation.cs : Entry ");
            ReadOnlyCollection<string> windowHandles = null;
            wait.Until((d) => (windowHandles = driver.Current(out desktop).WindowHandles).Count > 1);
            Console.WriteLine("Total open windows now:  " + driver.Current(out desktop).WindowHandles.Count);
            Console.WriteLine("In WaitTillNewWindowIsOpen method HousePresentation.cs : Exit ");
        }
    }
}
