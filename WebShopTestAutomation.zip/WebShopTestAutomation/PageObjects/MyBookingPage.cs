﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using WebShopTestAutomation.Drivers;
using OpenQA.Selenium.Interactions;
using OpenQA.Selenium.Support.UI;

namespace WebShopTestAutomation.PageObjects
{
    public class MyBookingPage
    {
        private WebDriverWait wait;

        WebDriver driver;
        bool desktop = true;
        public MyBookingPage(WebDriver webDriver)
        {

            this.driver = webDriver;

            wait = new WebDriverWait(driver.Current(out desktop), TimeSpan.FromSeconds(60));

        }

        public IWebElement GetMyBookingPage()
        {
            IWebElement myBookingPage = wait.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.ElementExists(By.Id("mybooking")));
            return myBookingPage;

        }
    }
}
