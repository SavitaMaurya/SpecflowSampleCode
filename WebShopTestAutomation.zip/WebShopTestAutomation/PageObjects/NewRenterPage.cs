﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using WebShopTestAutomation.Drivers;
using OpenQA.Selenium.Interactions;
using OpenQA.Selenium.Support.UI;

namespace WebShopTestAutomation.PageObjects
{
    public class NewRenterPage
    {
        private WebDriverWait wait;
         WebDriver driver;
        bool desktop = true;
        public NewRenterPage(WebDriver webDriver)
        {

            this.driver = webDriver;

            wait = new WebDriverWait(driver.Current(out desktop), TimeSpan.FromSeconds(60));

        }
        public IWebElement LogoOnExtranet()
        {
            IWebElement LogoLink = wait.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.ElementExists(By.XPath("//div[contains(@class, 'header__brand')]/a")));
            return LogoLink;
        }
        public IWebElement GetOfferButton()
        {
            IWebElement offerButton = wait.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.ElementExists(By.XPath("//span[contains(@class, 'landing-menu__cta')]/a")));
            return offerButton;

        }
    }
}
