﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using WebShopTestAutomation.Drivers;
using OpenQA.Selenium.Interactions;
using OpenQA.Selenium.Support.UI;

namespace WebShopTestAutomation.PageObjects
{
    public class LoginPage
    {

        private WebDriverWait wait;

        WebDriver driver;
        bool desktop = true;
        public LoginPage(WebDriver webDriver)
        {

            this.driver = webDriver;

            wait = new WebDriverWait(driver.Current(out desktop), TimeSpan.FromSeconds(60));

        }

        public IList<IWebElement> GetCookieButton()
        {
            IList<IWebElement> CookieButton = driver.Current(out desktop).FindElements(By.XPath("//button[contains(@class, 'cc_btn_accept_all')]"));
            //IList<IWebElement> CookieButton = driver.Current(out desktop).FindElements(By.Id("CybotCookiebotDialogBodyButtonAccept"));
            return CookieButton;

        }
        public IWebElement GetLoginForm()
        {
            IWebElement BurgerMenu = wait.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.ElementExists(By.Id("user-login-form")));
            return BurgerMenu;

        }

        public IWebElement GetEmailFieldOnLogin()
        {
            IWebElement EmailField = wait.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.ElementExists(By.Id("edit-name")));
            return EmailField;

        }

        public IWebElement GetEmailFieldOnSignUp()
        {
            IWebElement EmailField = wait.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.ElementExists(By.Id("edit-mail")));
            return EmailField;

        }

        public IWebElement GetPasswordFieldOnLogin()
        {
            IWebElement PasswordField = wait.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.ElementExists(By.Id("edit-pass")));
            return PasswordField;

        }

        public IWebElement GetPasswordFieldOnSignUp()
        {
            IWebElement PasswordField = wait.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.ElementExists(By.Id("edit-pass-pass1")));
            return PasswordField;

        }

        public IWebElement GetConfirmPasswordField()
        {
            IWebElement ConfirmPasswordField = wait.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.ElementExists(By.Id("edit-pass-pass2")));
            return ConfirmPasswordField;

        }

        public IWebElement GetLoginButton()
        {
            IWebElement LoginButton = wait.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.ElementExists(By.Id("edit-submit")));
            return LoginButton;

        }
        public IWebElement GetCreateProfileButton()
        {
            IWebElement CreateProfileButton = wait.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.ElementExists(By.Id("edit-submit")));
            return CreateProfileButton;

        }

        public IWebElement GetSignUpLink()
        {
            IWebElement SignUpLink = wait.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.ElementExists(By.XPath("//div[contains(@class, 'identity-forms__link')]/a")));
            return SignUpLink;

        }

        public IWebElement GetConfirmationLink()
        {
            IWebElement ConfirmationLink = wait.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.ElementExists(By.XPath("//div[contains(@class, 'identity-confirmation__link')]/a")));
            return ConfirmationLink;

        }

        public IWebElement GetFirstNameField()
        {
            IWebElement FirstNameField = wait.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.ElementExists(By.Id("edit-field-name-0-value")));
            return FirstNameField;

        }

        public IWebElement GetLastNameField()
        {
            IWebElement LastNameField = wait.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.ElementExists(By.Id("edit-field-last-name-0-value")));
            return LastNameField;

        }

        public IWebElement GetMathQuestion()
        {
            IWebElement MathQuestion = wait.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.ElementExists(By.XPath("//div[contains(@class, 'form-item-captcha-response')]/span")));
            return MathQuestion;

        }
        public IWebElement GetCaptchaInputField()
        {
            IWebElement CaptchaInputField = wait.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.ElementExists(By.Id("edit-captcha-response")));
            return CaptchaInputField;

        }

        public IWebElement GetReturnHomeField()
        {
            IWebElement ReturnHomeField = wait.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.ElementExists(By.Id("")));
            return ReturnHomeField;

        }
        
        public List<IWebElement> MyBookings()
        {
            //wait.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.ElementExists(By.XPath("//h2[contains(@class, 'my-bookings__card-header')]")));
            //List<IWebElement> myBookings = driver.Current(out desktop).FindElements(By.XPath("//h2[contains(@class, 'my-bookings__card-header')]")).ToList();

            // changes on 11 Dec 2019 when upcoming and past bookings are introduced
            wait.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.ElementExists(By.XPath("//a[contains(@class, 'my-bookings__booking-link')]")));
            List<IWebElement> myBookings = driver.Current(out desktop).FindElements(By.XPath("//a[contains(@class, 'my-bookings__booking-link')]")).ToList();
            return myBookings;

        }

    }
}
