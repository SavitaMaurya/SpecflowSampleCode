﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using WebShopTestAutomation.Drivers;
using OpenQA.Selenium.Interactions;
using OpenQA.Selenium.Support.UI;


namespace WebShopTestAutomation.PageObjects
{
    public class HomeOwnerPage
    {
        private WebDriverWait wait;

        WebDriver driver;
        bool desktop = true;
        public HomeOwnerPage(WebDriver webDriver)
        {

            this.driver = webDriver;

            wait = new WebDriverWait(driver.Current(out desktop), TimeSpan.FromSeconds(60));

        }
               
        public IWebElement GetHomeOwnerLogin()
        {
            IWebElement HomeOwnerLogin = wait.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.ElementExists(By.Id("user-login-form")));
            return HomeOwnerLogin;

        }
    }
}
