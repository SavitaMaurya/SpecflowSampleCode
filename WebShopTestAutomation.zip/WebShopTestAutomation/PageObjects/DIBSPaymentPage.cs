﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using WebShopTestAutomation.Drivers;
using OpenQA.Selenium.Support.UI;

namespace WebShopTestAutomation.PageObjects
{
    public class DIBSPaymentPage
    {
        private OpenQA.Selenium.Support.UI.WebDriverWait wait;
    
        WebDriver driver;
        bool desktop = true;
        public DIBSPaymentPage(WebDriver webDriver)
        {

            this.driver = webDriver;

            wait = new WebDriverWait(driver.Current(out desktop), TimeSpan.FromSeconds(60));

        }
        public IWebElement HeaderVisible()
        {
            IWebElement PropertyId = wait.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.ElementExists(By.XPath("///h2[contains(@class, 'card__header')]")));
            return PropertyId;
        }
        

        public IWebElement NameOnCard()
        {
            IWebElement nameOnCard = wait.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.ElementExists(By.Id("card_name")));
          
            return nameOnCard;
        }
        public IWebElement CardNum()
        {
            IWebElement cardNum = wait.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.ElementExists(By.Id("cardno")));
            return cardNum;
        }
        public IWebElement ExpMon()
        {
            IWebElement expMon = wait.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.ElementExists(By.Id("expmon")));
            return expMon;
        }
        public IWebElement ExpYear()
        {
            IWebElement expYear = wait.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.ElementExists(By.Id("expyear")));
            return expYear;
        }
        public IWebElement Cvv()
        {
            IWebElement cvv = wait.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.ElementExists(By.Id("card_cvv")));
            return cvv;
        }
        public IWebElement PayButton()
        {
            IWebElement payButton = wait.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.ElementExists(By.XPath("//button[contains(@class, 'booking-overview__confirm')]")));
            return payButton;
        }
        
    }
}
