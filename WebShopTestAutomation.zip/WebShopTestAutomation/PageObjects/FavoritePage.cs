﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using WebShopTestAutomation.Drivers;
using OpenQA.Selenium.Support.UI;

namespace WebShopTestAutomation.PageObjects
{
   public class FavoritePage
    {
        private WebDriverWait wait;
       
        WebDriver driver;
        bool desktop = true;
        public FavoritePage(WebDriver webDriver)
        {

            this.driver = webDriver;

            wait = new WebDriverWait(driver.Current(out desktop), TimeSpan.FromSeconds(60));

        }
        public List<IWebElement> FavoriteHouses()
        {
            wait.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.ElementExists(By.XPath("//div[contains(@class,'favourites-panel__item')]")));
            List<IWebElement> lstFavHouses = driver.Current(out desktop).FindElements(By.XPath("//div[contains(@class,'favourites-panel__item')]//div[contains(@class,'house-card--teaser')]")).ToList();
           
            return lstFavHouses;
        }

        public IWebElement FavoriteIcon()
        {
            IWebElement FavIcon = wait.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.ElementExists(By.XPath("//div[contains(@class,'favourite-box__icon')]")));
            return FavIcon;
        }

        public IWebElement GetListMapViewLink()
        {
            IWebElement FavIcon = wait.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.ElementExists(By.XPath("//a[contains(@class, 'favourites-panel__link')]")));
            return FavIcon;
        }


    }
}
