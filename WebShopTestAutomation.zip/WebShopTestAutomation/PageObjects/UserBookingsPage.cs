﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using WebShopTestAutomation.Drivers;
using OpenQA.Selenium.Interactions;
using OpenQA.Selenium.Support.UI;

namespace WebShopTestAutomation.PageObjects
{
    public class UserBookingsPage
    {

        private WebDriverWait wait;

        WebDriver driver;
        bool desktop = true;
        public UserBookingsPage(WebDriver webDriver)
        {

            this.driver = webDriver;

            wait = new WebDriverWait(driver.Current(out desktop), TimeSpan.FromSeconds(60));

        }

        public List<IWebElement> MyBookingLinks()
        {
            wait.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.ElementExists(By.XPath("//ul[contains(@class, 'my-bookings__list')]//a")));
            List<IWebElement> bookingLinks = driver.Current(out desktop).FindElements(By.XPath("//ul[contains(@class, 'my-bookings__list')]//a")).ToList();
            return bookingLinks;

        }

    }
}
