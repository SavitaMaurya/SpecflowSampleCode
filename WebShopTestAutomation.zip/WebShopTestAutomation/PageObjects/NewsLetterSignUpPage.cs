﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using WebShopTestAutomation.Drivers;
using OpenQA.Selenium.Interactions;
using OpenQA.Selenium.Support.UI;

namespace WebShopTestAutomation.PageObjects
{
    public class NewsLetterSignUpPage
    {
        private WebDriverWait wait;

        WebDriver driver;
        bool desktop = true;
        public NewsLetterSignUpPage(WebDriver webDriver)
        {

            this.driver = webDriver;

            wait = new WebDriverWait(driver.Current(out desktop), TimeSpan.FromSeconds(60));

        }

        public IWebElement GetNewsLetterPopUp()
        {
            IWebElement NewsLetterPopUp = wait.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.ElementExists(By.XPath("//div[contains(@class, 'newsletter-modal')]//form[contains(@class, 'newsletter-form--brochure-block')]")));
            return NewsLetterPopUp;

        }
        public IWebElement GetEmailFieldOnNewsLetterSignUp()
        {
            IWebElement EmailField = wait.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.ElementExists(By.XPath("//div[contains(@class, 'newsletter-modal')]//input[@id ='email']")));
            return EmailField;

        }

        public IWebElement GetNewsLetterSignUpSubmit()
        {
            IWebElement NewsLetterSignUpSubmit = wait.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.ElementExists(By.XPath("//div[contains(@class, 'newsletter-modal')]//form[contains(@class, 'newsletter-form--brochure-block')]//button[@type='submit']")));
            return NewsLetterSignUpSubmit;

        }

        public IWebElement GetNewsLetterSignUpSuccess()
        {
            IWebElement NewsLetterSignUpSuccess = wait.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.ElementExists(By.XPath("//span[contains(@class, 'newsletter-form__success-title-icon')]")));
            return NewsLetterSignUpSuccess;

        }
    }
}
