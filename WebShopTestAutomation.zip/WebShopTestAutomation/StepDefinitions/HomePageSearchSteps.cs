﻿using System;
using TechTalk.SpecFlow;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;
using OpenQA.Selenium.Chrome;
using WebShopTestAutomation.Drivers;
using System.Configuration;
using System.Text.RegularExpressions;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.Drawing;
using WebShopTestAutomation.PageObjects;
using System.Collections.Generic;
using System.Linq;
using Microsoft.Extensions.Configuration;
using OpenQA.Selenium.Interactions;
using System.Threading;
using System.IO;
using System.Reflection;
using ImageMagick;

namespace WebShopTestAutomation
{
    [Binding]

    public class CheckTheSearchFunctionalityToFindHolidayHomesSteps
    {
        private readonly WebDriver driver;

        public CheckTheSearchFunctionalityToFindHolidayHomesSteps(WebDriver webDriver)
        {
            driver = webDriver;
        }


        string location = string.Empty;

        SeleniumTests obj = new SeleniumTests();


        string catalogueNumber = string.Empty;
        int HouseCountOrig = 0;
        int HouseCountFinal = 0;

        string rentalPriceSearchPage = string.Empty;


        string rentalPriceHP = string.Empty;
        public static bool desktop = true;



        [Given(@"I am on Novasol website(.*)")]
        public void GivenIAmOnNovasolWebsite(string url)
        {
            var _driver = driver.Current(out desktop);

            try
            {
                url = Regex.Replace(url, @"\s", "");

                if (desktop)
                {
                    _driver.Manage().Window.Maximize();
                }

                string assemblyrunningPath = new FileInfo(Assembly.GetExecutingAssembly().Location).ToString();

                string configPath = Path.GetFullPath(Path.Combine(assemblyrunningPath, @".."));
                var config = new ConfigurationBuilder().SetBasePath(configPath).AddJsonFile("specflow.json").Build();

                string baseUrl = config["novasolBaseUrl"];

                string fullUrl = string.Format("{0}{1}", baseUrl, url);
                
                _driver.Navigate().GoToUrl(fullUrl);
                Console.WriteLine(fullUrl);

                _driver.Manage().Cookies.DeleteAllCookies();
                //Cookie c = new Cookie("gtm_use_cdn", "TRUE");

                Cookie cookie = new Cookie("automated_testing", "md5(Ymd)");

                _driver.Manage().Cookies.AddCookie(cookie);

             
            }
            catch (Exception ex)
            {
                driver.Quit();
                throw ex;
            }
        }

        [Given(@"I close the cookies button if pops up")]
        public void GivenICloseTheCookiesButtonIfPopsUp()
        {
            try
            {
                obj.ClickOnCookiesButton(driver);

                driver.Current(out desktop).Manage().Timeouts().PageLoad = TimeSpan.FromSeconds(60);
                ////saved homepage image
                //MagickImage img1 = new MagickImage(@"..\SampleImages\HomePage.png");

                ////take screenshot
                //((ITakesScreenshot)driver.Current(out desktop)).GetScreenshot().SaveAsFile("TestHomePage.png", ScreenshotImageFormat.Png);

                //MagickImage img2 = new MagickImage(@"..\TestResults\TestHomePage.png");

                //var imgDiff = new MagickImage();

                //img1.Compare(img2, new ErrorMetric(), imgDiff);
                //imgDiff.Write(@"..\TestResults\TestDiffHomePage.png");


            }
            catch (Exception ex)
            {
                driver.Quit();
                throw ex;
            }
        }


        [When(@"I clicked on Anywhere in Europe option and started writing location name (.*)")]
        public void WhenIClickedOnAnywhereInEuropeOptionAndStartedWritingLocationName(string p0)
        {
            try
            {
                obj.ClickAndWriteOnAnywhereInWorldOption(driver, p0);
                location = p0;
            }
            catch (Exception ex)
            {
                driver.Quit();
                throw ex;
            }
        }


        [Then(@"I clicked on Anywhere in Europe option and started changing location name (.*)")]
        public void ThenIClickedOnAnywhereInEuropeOptionAndStartedChangingLocationName(string p1)
        {
            try
            {
                HomePage objHomePage = new HomePage(driver);
                SearchResultsPage objSearchResults = new SearchResultsPage(driver);

                if (!desktop)
                {
                    List<IWebElement> searchFilters = objSearchResults.GetSearchFilterText();

                    IWebElement destinationFilter = searchFilters[0];

                    if (destinationFilter.Enabled)
                    {
                        ((IJavaScriptExecutor)driver.Current(out desktop)).ExecuteScript("arguments[0].click();", destinationFilter);

                    }
                }

                IWebElement DesinationClose = objHomePage.GetDesinationClose();

                if (DesinationClose.Enabled)
                {
                    ((IJavaScriptExecutor)driver.Current(out desktop)).ExecuteScript("arguments[0].click();", DesinationClose);

                }
                driver.Current(out desktop).Manage().Timeouts().PageLoad = TimeSpan.FromSeconds(60);

                obj.ClickAndWriteOnAnywhereInWorldOption(driver, p1);
                location = p1;
            }
            catch (Exception ex)
            {
                driver.Quit();
                throw ex;
            }
        }

        [Then(@"location should be auto populate which I can select")]
        public void ThenLocationShouldBeAutoPopulateWhichICanSelect()
        {
            try
            {
                obj.SelectlocationfromDropdown(driver);
            }
            catch (Exception ex)
            {
                driver.Quit();
                throw ex;
            }

        }


        [When(@"I choose date filters for Arrival and Departure")]
        public void WhenIChooseDateFiltersForArrivalAndDeparture()
        {
            try
            {
                obj.ChooseDateFiltersForArrivalAndDeparture(driver);
            }
            catch (Exception ex)
            {
                driver.Quit();
                throw ex;


            }
        }

        [When(@"I choose date filters in popular period (.*) and (.*)")]
        public void WhenIChooseDateFiltersInPopularPeriod(string strArrivalDate, string strDepartureDate)
        {
            try
            {
                string assemblyrunningPath = new FileInfo(Assembly.GetExecutingAssembly().Location).ToString();

                string configPath = Path.GetFullPath(Path.Combine(assemblyrunningPath, @".."));
                var config = new ConfigurationBuilder().SetBasePath(configPath).AddJsonFile("specflow.json").Build();

                DateTime popArrivalDate = new DateTime();
                popArrivalDate = DateTime.ParseExact(strArrivalDate, "MM/dd/yyyy", null);

                DateTime popDepartureDate = new DateTime();
                popDepartureDate = DateTime.ParseExact(strDepartureDate, "MM/dd/yyyy", null);


                DateTime arrivalDate = new DateTime();

                arrivalDate = SeleniumTests.GetRandomDate(popArrivalDate, popDepartureDate);
                
                DateTime deptDate = new DateTime();
                
                deptDate = arrivalDate.AddDays(Convert.ToInt32(config["DepartureInDays"]));

                Console.WriteLine("Popular Arrival date period: " + popArrivalDate + " Departure date : " + popDepartureDate);

                Console.WriteLine(" Arrival date Selected in date filter: " + arrivalDate + " Departure date selected: " + deptDate);

                if(arrivalDate < DateTime.UtcNow)
                {
                    Assert.IsTrue(true,"Skipping test as arrival date is in the past ");
                }

                HomePage objHomePage = new HomePage(driver);

                int Count = 0;

                //Click the calender arrow buttons 

                int arrowClickCount = 0;

                if( DateTime.UtcNow.Month < arrivalDate.Month)
                {
                    arrowClickCount = (arrivalDate.Month - DateTime.UtcNow.Month) - 1; 
                }
                else
                {
                    arrowClickCount = (DateTime.UtcNow.Month - arrivalDate.Month) + 4;
                }


                IWebElement calenderArrow = null;

                if(arrowClickCount > 0)
                { 
                   calenderArrow = objHomePage.GetCalenderRightArrow();

                if (calenderArrow.Enabled)
                {
                    for (int i = 0; i < arrowClickCount; i++)
                    {
                        ((IJavaScriptExecutor)driver.Current(out desktop)).ExecuteScript("arguments[0].click();", calenderArrow);
                        Thread.Sleep(1000);


                    }
                }
                }

                List<IWebElement> lstArrivalDate = objHomePage.SelectArrivalDate().ToList();
              
                bool arrivalDateSelected = false;

            foreach (IWebElement element in lstArrivalDate.ToList())
            {
                Count = 1;
                if (arrivalDate.Day.ToString() == element.Text)
                {
                    ((IJavaScriptExecutor)driver.Current(out desktop)).ExecuteScript("arguments[0].click();", element);
                    arrivalDateSelected = true;
                    break;

                }
                lstArrivalDate.Remove(element);

                Count++;
            }


            if (!arrivalDateSelected)
            {

                calenderArrow = objHomePage.GetCalenderRightArrow();

                if (calenderArrow.Enabled)
                {
                    ((IJavaScriptExecutor)driver.Current(out desktop)).ExecuteScript("arguments[0].click();", calenderArrow);
                }

                lstArrivalDate = objHomePage.SelectArrivalDate().ToList();

                foreach (IWebElement element in lstArrivalDate.ToList())
                {
                    Count = 1;
                    if (arrivalDate.Day.ToString() == element.Text)
                    {
                        ((IJavaScriptExecutor)driver.Current(out desktop)).ExecuteScript("arguments[0].click();", element);
                        arrivalDateSelected = true;
                        break;

                    }
                    lstArrivalDate.Remove(element);

                    Count++;
                }

            }
            //Check departure calender is open or not

            bool departureDateSelected = false;

            List<IWebElement> lstDepartureDate = lstArrivalDate; //Remaining dates in calender

            foreach (IWebElement element in lstDepartureDate)
            {
                if (deptDate.Day.ToString() == element.Text)
                {
                    ((IJavaScriptExecutor)driver.Current(out desktop)).ExecuteScript("arguments[0].click();", element);
                    departureDateSelected = true;
                    break;
                }
            }

            if (!departureDateSelected)
            {

                 calenderArrow = objHomePage.GetCalenderRightArrow();

                if (calenderArrow.Enabled)
                {
                    ((IJavaScriptExecutor)driver.Current(out desktop)).ExecuteScript("arguments[0].click();", calenderArrow);
                }

                lstDepartureDate = objHomePage.SelectArrivalDate().ToList();

                foreach (IWebElement element in lstDepartureDate.ToList())
                {
                    Count = 1;
                    if (deptDate.Day.ToString() == element.Text)
                    {
                        ((IJavaScriptExecutor)driver.Current(out desktop)).ExecuteScript("arguments[0].click();", element);
                        departureDateSelected = true;
                        break;

                    }
                    lstDepartureDate.Remove(element);

                    Count++;
                }

            }
            }
            catch (Exception ex)
            {
                driver.Quit();
                throw ex;


            }

        }

        [Then(@"I can see popular dates persuasive messaging (.*)")]
        public void ThenICanSeePopularDatesPersuasiveMessaging(int p0)
        {
            try
            {
                SearchResultsPage objSearchResultsPage = new SearchResultsPage(driver);

                IWebElement PopularDateMessage = objSearchResultsPage.GetPopularDateMessage();

                if(!PopularDateMessage.Enabled)
                {
                    Assert.Fail("Popular persuasive messaging not shown");
                }

                if(p0 == 1)
                {
                    driver.Quit();
                }
            }
            catch (Exception ex)
            {
                //take screenshot
                ((ITakesScreenshot)driver.Current(out desktop)).GetScreenshot().SaveAsFile("PopularDates.png", ScreenshotImageFormat.Png);

                driver.Quit();
                throw ex;
            }
        }



        [When(@"I clicked on Search option")]
        public void WhenIClickedOnSearchOption()
        {
            try
            {
                obj.ClickOnHomePageSearchButton(driver);
            }
            catch (Exception ex)
            {
                driver.Quit();
                throw ex;
            }
        }

        [Then(@"I clicked again on Search option")]
        public void ThenIClickedAgainOnSearchOption()
        {
            try
            {
                HomePage objHomePage = new HomePage(driver);

                IWebElement searchElement = objHomePage.GetSearchButton();
                bool isenabled = searchElement.Enabled;

                if (isenabled)
                {
                    ((IJavaScriptExecutor)driver.Current(out desktop)).ExecuteScript("arguments[0].click();", searchElement);

                }
            }
            catch (Exception ex)
            {
                driver.Quit();
                throw ex;
            }
        }

        int HouseCount = 0;
        [Then(@"Holiday homes should populate")]
        public void ThenHolidayHomesShouldPopulate()
        {
            
            try
            {
                SearchResultsPage objSearchResults = new SearchResultsPage(driver);
                driver.Current(out desktop).Manage().Timeouts().PageLoad = TimeSpan.FromSeconds(60);
                HouseCount = objSearchResults.ResultHouseCount();
                if(HouseCount> 0)
                { 
                obj.CheckContentOnSearchFilterResultPage(driver, location);
                }
                else
                {
                    Console.WriteLine("No houses available for the search combination");
                    driver.Quit();
                }
                Assert.AreEqual(0, 1);
                driver.Quit();
            }
            catch (Exception ex)
            {
                driver.Quit();
                throw ex;
            }
        }


        [Then(@"there should be no duplicate house on page")]
        public void ThenThereShouldBeNoDuplicateHouseOnPage()
        {
            try
            {
                bool duplicateHouse = obj.CheckForDuplicateHouseOnResultPage(driver);

                if (duplicateHouse)
                {
                    Assert.Fail();

                }
            }
            catch (Exception ex)
            {
                driver.Quit();
                throw ex;
            }
        }

        [Then(@"I scrolled down till the last house available on the page")]
        public void ThenIScrolledDownTillTheLastHouseAvailableOnThePage()
        {
            try
            {
                SearchResultsPage objSearchResults = new SearchResultsPage(driver);

                IWebElement houselocation = obj.ScrollDownToBottomOfSearchResultsPage(driver);

                rentalPriceSearchPage = objSearchResults.GetRentalPrice();

                obj.SelectHousefromtheListofHouses(driver, houselocation);
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex);
                driver.Quit();
                throw ex;
            }
        }


        [Then(@"I Click on Go to Property button of the first house availble")]
        public void ThenIClickOnGoToPropertyButtonOfTheFirstHouseAvailble()
        {
            try
            {
                SearchResultsPage objSearchResults = new SearchResultsPage(driver);
                //  driver.Current(out desktop).Manage().Timeouts().PageLoad = TimeSpan.FromSeconds(60);
                List<IWebElement> houselocation = objSearchResults.GetFirstHousePropertyButton();

                if (houselocation.Count > 0)
                {
                    obj.SelectHousefromtheListofHouses(driver, houselocation[0]);
                }
                else
                {
                    driver.Quit();
                }
            }
            catch (Exception ex)
            {
                driver.Quit();
                throw ex;
            }
        }


        [Then(@"House presentation page should open and should look correct (.*)")]
        public void ThenHousePresentationPageShouldOpenAndShouldLookCorrect(int p0)
        {
            try
            {
                driver.Current(out desktop).Manage().Timeouts().PageLoad = TimeSpan.FromSeconds(60);
                //Close for any pop up window warning if appears
                bool isAlert = obj.IsDialogPresent(driver);

                if (isAlert)
                {
                    Console.WriteLine("Alert Present");
                    driver.Current(out desktop).SwitchTo().Alert().Accept();
                }

                obj.ClickOnCookiesButton(driver);

                
                catalogueNumber = obj.VerifyHousePresentationPage(driver, out rentalPriceHP);

                if (p0 == 1)
                {
                    driver.Quit();
                }

            }
            catch (Exception ex)
            {
                driver.Quit();
                throw ex;
            }
        }


        [Then(@"House rental price should be same on Search Result and House presentation page")]
        public void ThenHouseRentalPriceShouldBeSameOnSearchResultAndHousePresentationPage()
        {
            try
            {
                Assert.AreEqual(rentalPriceSearchPage, rentalPriceHP);
            }
            catch (Exception ex)
            {
                driver.Quit();
                throw ex;
            }
        }


        string rentalPriceBookingPage = string.Empty;

        [Then(@"House rental price should be same on House presentation page and Booking Flow page")]
        public void ThenHouseRentalPriceShouldBeSameOnHousePresentationPageAndBookingFlowPage()
        {
            try
            {
                BookingFlowPage objBookingFlow = new BookingFlowPage(driver);
                rentalPriceBookingPage = objBookingFlow.GetHouseRental().Text;
                rentalPriceBookingPage = Regex.Replace(rentalPriceBookingPage, @"\s", "");

                int startindex = rentalPriceBookingPage.IndexOf(",");
                rentalPriceBookingPage = rentalPriceBookingPage.Remove(startindex, 3);

                Assert.AreEqual(rentalPriceHP, rentalPriceBookingPage);
            }
            catch (Exception ex)
            {
                driver.Quit();
                throw ex;
            }
        }


        [When(@"I clicked on Book button")]
        public void WhenIClickedOnBookButton()
        {
            try
            {
                obj.ClickOnBookButton(driver);
            }
            catch (Exception ex)
            {
                driver.Quit();
                throw ex;
            }
        }

        [Then(@"I should be directed to Novasol Booking page (.*)")]
        public void ThenIShouldBeDirectedToNovasolBookingPage(int driverQuit)
        {
            try
            {
                obj.VerifyBookingFlowPage(driver, catalogueNumber, Convert.ToBoolean(driverQuit));
            }
            catch (Exception ex)
            {
                driver.Quit();
                throw ex;
            }
        }
        [Then(@"I check the house count available")]
        public void ThenICheckTheHouseCountAvailable()
        {
            try
            {
                if(HouseCount > 0)
                { 
                driver.Current(out desktop).Manage().Timeouts().PageLoad = TimeSpan.FromSeconds(60);
                Thread.Sleep(2000);
                HouseCountFinal = obj.GetHouseCountOnSearchResultPage(driver);

                Console.WriteLine("House Count Final: " + HouseCountFinal);

                }
            }
            catch (Exception ex)
            {
                driver.Quit();
                throw ex;
            }
        }
        [When(@"I check the house count available")]
        public void WhenICheckTheHouseCountAvailable()
        {

            try
            {
                driver.Current(out desktop).Manage().Timeouts().PageLoad = TimeSpan.FromSeconds(60);
                Thread.Sleep(2000);
                HouseCountFinal = obj.GetHouseCountOnSearchResultPage(driver);

                Console.WriteLine("House Count Final: " + HouseCountFinal);
            }
            catch (Exception ex)
            {
                driver.Quit();
                throw ex;
            }
        }

        [Then(@"save the result count temporarily")]
        public void ThenSaveTheResultCountTemporarily()
        {
            try
            {
                if (HouseCount > 0)
                {
                    HouseCountOrig = HouseCountFinal;
                    Console.WriteLine("House Count Original: " + HouseCountOrig);
                }
            }
            catch (Exception ex)
            {
                driver.Quit();
                throw ex;
            }
        }

        [When(@"I choose date filters for Arrival and Departure in a future")]
        public void WhenIChooseDateFiltersForArrivalAndDepartureInAFuture()
        {

            try
            {
                HousePresentation objHousePresentation = new HousePresentation(driver);
                DateTime cdate = new DateTime();
                cdate = DateTime.Today.Date;

                string assemblyrunningPath = new FileInfo(Assembly.GetExecutingAssembly().Location).ToString();

                string configPath = Path.GetFullPath(Path.Combine(assemblyrunningPath, @".."));
                var config = new ConfigurationBuilder().SetBasePath(configPath).AddJsonFile("specflow.json").Build();
                //var config = new ConfigurationBuilder().AddJsonFile("specflow.json").Build();

                DateTime arrivalDate = new DateTime();

                arrivalDate = cdate.AddDays(Convert.ToInt32(config["ArrivalInDays"]));

                DateTime deptDate = new DateTime();

                deptDate = arrivalDate.AddDays(Convert.ToInt32(config["DepartureInDays"]));

                HomePage objHomePage = new HomePage(driver);

                DateTime newArrivalDate = new DateTime();
                newArrivalDate = arrivalDate.AddMonths(Convert.ToInt32(config["TotalFutureMonths"]));
                DateTime newDeptDate = new DateTime();
                newDeptDate = deptDate.AddMonths(Convert.ToInt32(config["TotalFutureMonths"]));

                Console.WriteLine("Arrival date selected: " + newArrivalDate + " Departure date selected: "+ newDeptDate);

                int Count = 0;

                //Click the calender arrow buttons 

                IWebElement calenderArrow = objHousePresentation.GetCalenderRightArrow();

                if (calenderArrow.Enabled)
                {
                    for (int i = 0; i < Convert.ToInt32(config["TotalFutureMonths"]); i++)
                    {
                        ((IJavaScriptExecutor)driver.Current(out desktop)).ExecuteScript("arguments[0].click();", calenderArrow);
                        Thread.Sleep(1000);


                    }
                }

                //Click the calender arrow buttons 

                List<IWebElement> lstArrivalDate = objHomePage.SelectArrivalDate().ToList();


                foreach (IWebElement element in lstArrivalDate.ToList())
                {
                    Count = 1;
                    if (newArrivalDate.Day.ToString() == element.Text)
                    {

                        ((IJavaScriptExecutor)driver.Current(out desktop)).ExecuteScript("arguments[0].click();", element);

                        break;

                    }
                    lstArrivalDate.Remove(element);

                    Count++;
                }

                //Check departure calender is open or not

                List<IWebElement> lstDepartureDate = lstArrivalDate; //Remaining dates in calender

                foreach (IWebElement element in lstDepartureDate)
                {
                    if (newDeptDate.Day.ToString() == element.Text)
                    {

                        ((IJavaScriptExecutor)driver.Current(out desktop)).ExecuteScript("arguments[0].click();", element);
                        break;
                    }
                }
            }

            catch (Exception ex)
            {
                driver.Quit();
                throw ex;
            }
        }

        [When(@"Choose Two adults,two children and a pet from Guest Picker")]
        public void WhenChooseTwoAdultsTwoChildrenAndAPetFromGuestPicker()
        {
            try
            {
                SearchResultsPage objSearchResultsPage = new SearchResultsPage(driver);
                IWebElement GuestPicker = objSearchResultsPage.GetGuestPickerDropdown();



                bool isenabled = GuestPicker.Enabled;



                if (isenabled)
                {
                    //Select 2 children
                    List<IWebElement> lstGuestDropdwn = objSearchResultsPage.SelectFromGuestPickerDropdown().ToList();

                    IWebElement selectChildren = lstGuestDropdwn[1];
                    bool selectChildrenEnabled = selectChildren.Enabled;


                    if (selectChildrenEnabled)
                    {
                        ((IJavaScriptExecutor)driver.Current(out desktop)).ExecuteScript("arguments[0].click();", selectChildren);


                        ((IJavaScriptExecutor)driver.Current(out desktop)).ExecuteScript("arguments[0].click();", selectChildren);

                    }

                    //Select 1 Pet

                    IWebElement selectPets = lstGuestDropdwn[2];
                    bool selectPetsEnabled = selectPets.Enabled;
                    if (selectPetsEnabled)
                    {
                        ((IJavaScriptExecutor)driver.Current(out desktop)).ExecuteScript("arguments[0].click();", selectPets);
                        // selectPets.SendKeys("01");
                        Thread.Sleep(1000);

                    }
                }

                IWebElement GuestPickerClose = objSearchResultsPage.GetCloseGuestPicker();


                if (GuestPickerClose.Enabled)
                {
                    ((IJavaScriptExecutor)driver.Current(out desktop)).ExecuteScript("arguments[0].click();", GuestPickerClose);

                }

            }

            catch (Exception ex)
            {
                driver.Quit();
                throw ex;
            }


        }

        //[Then(@"I filtered the houses by selecting on Dishwasher")]
        //public void ThenIFilteredTheHousesBySelectingOnDishwasher()
        //{
        //    try
        //    {

        //        if (!desktop)
        //        {
        //            obj.ClickOnFilterIcon(driver);
        //        }
        //        SearchResultsPage objSearchResults = new SearchResultsPage(driver);
        //        IWebElement facilitiesOption = objSearchResults.GetFacilitiesOption();
        //        bool facilitiesOptionEnabled = facilitiesOption.Enabled;

        //        if (facilitiesOptionEnabled)
        //        {
        //            ((IJavaScriptExecutor)driver.Current(out desktop)).ExecuteScript("arguments[0].scrollIntoView();", facilitiesOption);
        //            ((IJavaScriptExecutor)driver.Current(out desktop)).ExecuteScript("arguments[0].click();", facilitiesOption);

        //        }

        //        IWebElement dishwasherOption = objSearchResults.GetDiswasherFacility();
        //        bool dishwasherOptionEnabled = dishwasherOption.Enabled;

        //        if (dishwasherOptionEnabled)
        //        {
        //            ((IJavaScriptExecutor)driver.Current(out desktop)).ExecuteScript("arguments[0].click();", dishwasherOption);

        //        }
        //        if (!desktop)
        //        {
        //            obj.ClickSearchButtonAfterFilter(driver);
        //        }
        //        else
        //        {
        //            obj.CloseFacilityFilter(driver);
        //        }
        //        IWebElement SelectedFilter = objSearchResults.GetSelectedFilter();

        //        if(SelectedFilter.Enabled)
        //        {
        //            Console.WriteLine("Selected Utilty : " + SelectedFilter.Text);
        //        }


        //    }
        //    catch (Exception ex)
        //    {
        //        driver.Quit();
        //        throw ex;

        //    }

        //}
         
      


        [AfterTestRun]
        public static void AfterTestRun()
        {
            WebDriver webDriver = new WebDriver();
            webDriver.Quit();
            webDriver.Dispose();
        }


        [AfterFeature]
        public static void AfterFeature()
        {
            WebDriver webDriver = new WebDriver();
            webDriver.Quit();
            webDriver.Dispose();
        }

    }
}
