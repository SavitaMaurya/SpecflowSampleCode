﻿using System;
using System.Configuration;
using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using OpenQA.Selenium.Firefox;
using OpenQA.Selenium.IE;
using OpenQA.Selenium.Safari;
using OpenQA.Selenium.Support.UI;
using OpenQA.Selenium.Edge;
using Microsoft.Extensions.Configuration;
using OpenQA.Selenium.Appium;
using OpenQA.Selenium.Appium.Interfaces;
using OpenQA.Selenium.Appium.MultiTouch;
using OpenQA.Selenium.Interactions;
using OpenQA.Selenium.Remote;
using OpenQA.Selenium.Appium.Android;
using OpenQA.Selenium.Appium.Enums;
using System.Reflection;
using System.IO;

namespace WebShopTestAutomation.Drivers
{
    public class WebDriver
    {
        private IWebDriver _currentWebDriver;
        //private WebDriverWait _wait;
      
        public static bool isDesktop = true;
        public IWebDriver Current(out bool desktop)
        {
                desktop = true;
                if (_currentWebDriver == null)
                {
                   _currentWebDriver = GetWebDriver(out desktop);
                   isDesktop = desktop;
                }
                else
                {
                  desktop = isDesktop;
                }

                 return _currentWebDriver;
           
        }

        //public WebDriverWait Wait
        //{
        //    get
        //    {
        //        if (_wait == null)
        //        {
        //            this._wait = new WebDriverWait(Current, TimeSpan.FromSeconds(120));
        //        }
        //        return _wait;
        //    }
        //}

        private IWebDriver GetWebDriver(out bool desktop)
        {
            IWebDriver driver = null;
            desktop = true;
            try
            {
                AppiumOptions app_options = new AppiumOptions();
                ChromeOptions chrome_options = new ChromeOptions();
                SafariOptions safariOptions = new SafariOptions();
                string executingPath = Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location);
                Console.WriteLine("assemblyrunningPath : " + executingPath);

                //ChromeDriverService service = ChromeDriverService.CreateDefaultService(Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location));
                ChromeDriverService service = null;
                switch (Environment.GetEnvironmentVariable("Test_Browser"))
                {
                    
                    case "Desktop_IE":

                        Console.WriteLine("In Desktop IE mode");

                       // string ieDriverPath = @"\WebDriversSetup\IEDriver";
                        desktop = true;

                       // ieDriverPath = Path.GetFullPath(Path.Combine(executingPath + ieDriverPath));

                        var options = new InternetExplorerOptions();
                        options.IgnoreZoomLevel = true;
                        //options.AcceptInsecureCertificates = true; //IE DOESN'T ALLOW
                        //options.EnableNativeEvents = false; //AUTO SUGGEST LOCATION STOPPED POPING
                        options.InitialBrowserUrl = "http://localhost";
                        options.UnhandledPromptBehavior = UnhandledPromptBehavior.Accept;
                        options.IntroduceInstabilityByIgnoringProtectedModeSettings = true;
                        options.EnablePersistentHover = true;
                        InternetExplorerDriverService ieservice = InternetExplorerDriverService.CreateDefaultService(Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location));
                        driver = new InternetExplorerDriver(ieservice, options, TimeSpan.FromSeconds(180));

                        driver.Manage().Window.Maximize();
                        //the below works but hell slow
                        //InternetExplorerDriverService ieService = InternetExplorerDriverService.CreateDefaultService(Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location));
                        //driver = new InternetExplorerDriver(ieService, options, TimeSpan.FromSeconds(180));
                        break;
                    case "Desktop_Chrome":
                        Console.WriteLine("In Desktop Chrome mode");
                        desktop = true;
                        chrome_options.AddArgument("--disable-extensions");
                        chrome_options.AddArgument("--proxy-server='direct://'");
                        chrome_options.AddArgument("--proxy-bypass-list=*");
                        chrome_options.AddArgument("--no-sandbox");
                        service = ChromeDriverService.CreateDefaultService(Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location));
                        driver = new ChromeDriver(service, chrome_options, TimeSpan.FromSeconds(120));
                        driver.Manage().Window.Maximize();
                        break;
                  
                    default:
                        Console.WriteLine("In default : Test-Browser is - " + Environment.GetEnvironmentVariable("Test_Browser"));
                        desktop = true;
                        chrome_options.AddArgument("--start-maximized");
                        driver.Manage().Window.Maximize();
                        
                        driver = new ChromeDriver(chrome_options);
                        break;
                }
               
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex);
            }
            return driver;
        }

        public void Quit()
        {
            _currentWebDriver?.Quit();
        }

        public void Dispose()
        {
            _currentWebDriver?.Dispose();
        }
    }
}
